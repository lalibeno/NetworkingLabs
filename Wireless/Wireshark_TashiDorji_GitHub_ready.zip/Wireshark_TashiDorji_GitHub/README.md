# Wireshark Lab Notes

This folder contains the Markdown notes and their screenshot/photo assets.

## View locally
Open `Wireshark_TashiDorji.md` in a Markdown previewer. Keep the `images/` folder beside the Markdown file so its screenshots render.

## Publish on GitHub
Upload/commit both `Wireshark_TashiDorji.md` and the `images/` folder into the same repository directory. Do not upload only the `.md` file, because Markdown references the images as separate files.
